package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.login_dao;
import com.entity.login_entity;

public class loginService implements CommandAction_sample {

	@Override
	public String requestPro_action(HttpServletRequest request, HttpServletResponse response) throws Throwable {

		
		System.out.println("loging servide");
		
		String id=request.getParameter("input_id");
		String pwd=request.getParameter("input_pwd");
		
		login_dao dao = new login_dao();
		login_entity entity = dao.getUser(id,pwd);
		
		
		if(entity != null) {
			//세션설정
			HttpSession session=request.getSession();
			session.setAttribute("logOK", entity);
			return "login/loginOk.jsp";
		}else {
			return "login/loginFail.jsp";
		}
	}

	
	
	
}
