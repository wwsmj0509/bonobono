package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface CommandAction_sample {
	public String requestPro_action(HttpServletRequest request, 
			                 HttpServletResponse response) throws Throwable;
}
