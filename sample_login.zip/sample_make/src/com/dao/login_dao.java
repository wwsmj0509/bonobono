package com.dao;

import java.io.IOException;
import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.entity.login_entity;

public class login_dao {
	

	private static SqlSessionFactory factory;
	static {
		try {
			String resource="mySample/mybatis-config.xml";
			Reader reader=Resources.getResourceAsReader(resource);
			factory=new SqlSessionFactoryBuilder().build(reader);
		}catch(IOException e) {}
	}
	public login_entity getUser(String id, String pwd) {
		SqlSession session=factory.openSession();
		login_entity dto = new login_entity(id,pwd);
		System.out.println(dto.getId());
		System.out.println(dto.getPwd());
		login_entity entity = session.selectOne("mybatis.LoginMapper.getLoginUser",dto);
		session.close();
		System.out.println("getuser Clear");
		return entity;		
	}
	
	
	

}
