create table sampletable(


id varchar2(20) primary key ,
pwd varchar2(20)

)

drop table sampletable;

select * from sampletable

insert into sampletable(id,pwd) values('abcd','1111');

commit




create sequence sample_seq increment by 1 start with 1 nocycle nocache;




create table imageboard_sample (

seq number primary key,
imageid varchar(20) not null

)

create sequence seq_imageboard_sample increment by 1  start with 1 nocycle nocache;



select * from imageboard_sample;





